package com.mycompany.registration_and_login;

import java.util.Scanner;

public class Registration_And_Login {

    // Storing user data as static variables (for simple registration/login)
    static String storedUsername;//Declaring the username 
    static String storedPassword;// Decalaring the pasword
    static String storedPhoneNumber;// Declaring the phonenumber
    static String storedFirstName;//Declaring the first name 
    static String storedLastName;// Declaring the last name 

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // User registration
        String registrationMessage = registerUser(scanner);
        System.out.println(registrationMessage);

        // Login only if registration was successful
        if (registrationMessage.contains("successfully")) {
            System.out.println("\n--- Login ---");

            System.out.print("Enter your username: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter your password: ");
            String loginPassword = scanner.nextLine();

            boolean loginSuccess = loginUser(loginUsername, loginPassword);
            System.out.println(returnLoginStatus(loginSuccess));
        }

        scanner.close();
    }

    // Method to handle user registration
    public static String registerUser(Scanner scanner) {
        // Collecting personal info
        System.out.print("Enter your first name: ");
        storedFirstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        storedLastName = scanner.nextLine();

        // Username creation with validation
        do {
            System.out.print("Create a username (must include '_' and be 5 characters or less): ");
            storedUsername = scanner.nextLine();

            if (!checkUserName(storedUsername)) {
                System.out.println("Invalid username. Try again.\n");
            }

        } while (!checkUserName(storedUsername));

        // Password creation with validation
        do {
            System.out.print("Create a password (min 8 characters, must include capital letter, number, and special character): ");
            storedPassword = scanner.nextLine();

            if (!checkPasswordComplexity(storedPassword)) {
                System.out.println("Password must contain:");
                System.out.println("- At least 8 characters");
                System.out.println("- One capital letter");
                System.out.println("- One number");
                System.out.println("- One special character (!@#$%^&*)\n");
            }

        } while (!checkPasswordComplexity(storedPassword));

        // Phone number validation
        do {
            System.out.print("Enter your cellphone number with country code (e.g., +27xxxxxxxxx): ");
            storedPhoneNumber = scanner.nextLine();

            if (!checkPhoneNumberWithCountryCode(storedPhoneNumber)) {
                System.out.println("Invalid phone number. It must:");
                System.out.println("- Start with '+' and country code");
                System.out.println("- Only contain digits after '+'");
                System.out.println("- Be between 10 and 15 characters long\n");
            }

        } while (!checkPhoneNumberWithCountryCode(storedPhoneNumber));

        return "User has been registered successfully.";
    }

    // Method to verify login credentials
    public static boolean loginUser(String username, String password) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    // Method to return login result message
    public static String returnLoginStatus(boolean isSuccess) {
        if (isSuccess) {
            return "Welcome " + storedFirstName + ", " + storedLastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Checks username rules
    public static boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    // Checks password rules
    public static boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*[0-9].*") &&
               password.matches(".*[!@#$%^&*].*");
    }

    // Checks if phone number includes country code and valid format
    public static boolean checkPhoneNumberWithCountryCode(String number) {
        return number.matches("\\+[0-9]{9,14}");
    }
}
